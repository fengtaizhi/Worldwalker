# Worldwalker — Simplified Turn-Based Prototype (English)

Open the standalone HTML in a desktop browser. All scripts, styles and artwork are embedded; no internet connection is required.

Select Learn to Play for a guided practice match. Place two 5-second monsters, watch their parallel arrival, then compare a 40-second deployment with a 7-second turn deadline. Both sides lose their unfinished cards to banishment. Restart or exit at any time; your previous match and tactical plan are restored on exit. The lesson does not save over your configuration or decks.

Choose Match / Deck to select each side, then start PvE or AI vs AI. Each turn automatically pauses for planning. Drag cards into slots and select Execute & Resume. Space toggles Tactical Pause. Rules explains all timing terms; Placement means deployment starts, Arrival means a monster finishes deployment.

This edition translates the simplified-response turn-based prototype and adds an interactive tutorial. Normal match mechanics are unchanged. The Chinese version and the three other variants remain preserved. English settings and saved decks use separate local storage; existing deck JSON files may be imported. Custom names entered by a user are kept verbatim.
